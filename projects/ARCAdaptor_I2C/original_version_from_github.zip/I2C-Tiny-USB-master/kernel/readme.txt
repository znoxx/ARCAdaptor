This kernel driver is outdated and only for use with 
kernels < 2.6.22. Since 2.6.22 the i2c-tiny-usb kernel
driver is part of the official kernel source tree.